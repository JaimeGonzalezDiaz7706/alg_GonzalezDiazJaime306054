package p0;
import java.util.ArrayList;
public class JavaA4
{

public static void primoA4(int m)
{
boolean[] listaNumeros = new boolean[m+1];
for(int i=0; i<=m; i++)
{
    listaNumeros[i]=true;
}
int x=2;
while(x*x<=m)
{
    if(listaNumeros[x])
    {
        for(int paso =x*x;paso<=m;paso+=x){
            listaNumeros[paso]=false;
        }
    }
    x++;
}
int contPrimos=0;
for (int i=2;i<=m;i++)
    {
        if(listaNumeros[i])
        {
            contPrimos++;
        }
    }
    System.out.println("Hasta "+m+" hay"+contPrimos+"primos");
}


public static void main (String arg [] ) {
    System.out.println("TIEMPO EN JAVA DEL ALGORITMO A4");
    long t1, t2;

    for (int n = 5000; n <= 1000000; n *= 2) {
        t1 = System.currentTimeMillis();
        
         primoA4(n); 

        t2 = System.currentTimeMillis();
        System.out.println("n=" + n + "**** tiempo = " + (t2 - t1) + " milisegundos");
    }
}

} 

